# Ride Garage — multi-channel release checklist (October 14, 2026)

## Distribution strategy

1. **PWA (immediate)**: serve the live site over HTTPS with manifest and service worker. On iPhone, Safari -> Share -> Add to Home Screen. On Android, Chrome -> Install app/Add to Home screen. Test both on clean devices.
2. **Direct Android APK**: compile and sign a release APK in Android Studio; host it with checksum/version information. Users must explicitly approve installation from an external source. Never distribute a debug APK as a production release.
3. **Google Play**: build a signed Android App Bundle (.aab), not just APK, targeting Android 16 / API 36 or higher for a new submission under the requirements effective Aug 31, 2026. Register a Play Console developer account ($25 one-time). New personal accounts created after Nov 13, 2023 generally must have at least 12 closed-testers continuously opted in for 14 days before applying for production access.
4. **iOS TestFlight/App Store**: compile and sign through Xcode on macOS, join Apple Developer Program ($99/year in the US; local charges may vary). Test through TestFlight and submit through App Store Connect. An unsigned IPA cannot be publicly installed by arbitrary iPhone users; PWA is the direct-install route for general iPhone users outside the store.

## Build preparation

- Use Node 22+ and the Android Studio / Xcode versions required by the installed Capacitor major version. The current starter package specifies Capacitor 7; confirm environment and upgrade deliberately if adopting Capacitor 8.
- Run `npm install` then `npm run prepare:web` to fetch the latest website; inspect `www/` and config.js; run `npm run android:init` or `npm run ios:init` once, then `npm run sync` and open the native project.
- Change the sample `com.ridegarage.app` identifier before publishing to an identifier you own; once published, changing it creates a different app.
- Set native app name, orange/black icons, launch screen, version name and build number; use distinct version numbers for subsequent uploads.
- For Google Play, verify Gradle targetSdk 36+ in the *generated Android project* before building the AAB. Do not assume it automatically meets 2026 policy.
- Keep Supabase `anon`/publishable client key only (never service-role key). Verify authentication callback redirects for iOS/Android app origin; confirm images, camera/photo library, sharing, external links, network access and backup import/export on real devices.
- Native local storage does NOT share data with browser PWA. Export backup in the website and import in native app; test restore on disposable data first.

## Mandatory app review / privacy QA

- Apple guideline 4.2: app must offer meaningful utility/features beyond a repackaged site; Ride Garage's offline garage log, service history, trip/fuel utilities can help if genuinely functional and polished. Review is not guaranteed.
- If the Social feature supports user account creation, provide in-app initiation of account deletion (Apple 5.1.1(v)) and review applicable Google Play account-deletion requirements, including deletion request web URL.
- Host an accurate privacy policy and support/contact page. Disclose social posts/photos, profile/login data, crash/analytics information (if added), Supabase processing, storage, deletion process and support contact as actually implemented; avoid unsupported promises.
- Provide mechanisms to report and block abusive users, moderation contact and working reporting workflow for community content. Test report, block, account deletion, and enforcement.
- Complete store data safety and App Privacy declarations truthfully; add any permission purpose strings (camera/photo access etc.) required by native plugin use.
- Prepare screenshots from **actual** iPhone and Android builds at current store-approved sizes, app icon(s), promotional imagery, description, category, age ratings, content disclosures and reviewer test credentials if login is needed.
- Test offline behavior, narrow phones, notched iPhones, Android navigation bars, 200% text scaling, landscape handling, interrupted photo uploads, background/resume, app upgrade, and bad network connections.

## Store listing copy (draft; verify all features work in the native builds)

**Name:** Ride Garage

**Short description:** Track motorcycle upgrades, rides, maintenance, and fuel.

**Full description:** Ride Garage helps motorcycle enthusiasts keep their bike projects organized. Record upgrades and maintenance, track fuel and mileage, save trips and places, and manage your riding history in one place. Join other riders through the optional Social area to share motorcycle projects and posts. Export a backup of your personal garage records when switching devices.

**Support:** ridegarageapp@gmail.com (verify mailbox ownership and response process)

**Privacy policy:** use your actual hosted `privacy.html` URL after checking its text against current data handling.

## Release commands

```sh
npm install
npm run prepare:web
npm run android:init   # first time only
npm run ios:init       # first time only, macOS
npm run sync
npm run android:open  # Android Studio -> signed APK/AAB
npm run ios:open      # Xcode -> TestFlight/App Store archive
```

## References (official)

- https://capacitorjs.com/docs/getting-started/environment-setup
- https://developer.apple.com/app-store/review/guidelines/
- https://developer.apple.com/programs/
- https://developer.apple.com/go/?id=ar-ad-support
- https://support.google.com/googleplay/android-developer/answer/11926878
- https://support.google.com/googleplay/android-developer/answer/14151465
- https://support.google.com/googleplay/android-developer/answer/6112435
