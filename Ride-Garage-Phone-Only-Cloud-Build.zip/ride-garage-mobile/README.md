# Ride Garage — iPhone & Android native app starter

This project packages your existing Ride Garage site inside [Capacitor](https://capacitorjs.com/) for Android and iOS. It is a **buildable source starter**, not a precompiled `.apk` or `.ipa`. The repository website is not hard-coded as a remote `server.url` (which Capacitor discourages for production). Instead, the build includes local copies of the web files downloaded from the latest `main` branch.

## Getting started (computer needed)

1. Install Node.js (LTS), Python 3, and the native build tools.
2. Open a terminal in this extracted folder.
3. Run:

   ```sh
   npm install
   npm run prepare:web
   ```

4. Check that `www/index.html`, `www/config.js`, `www/icon-192.png` and `www/manifest.webmanifest` exist. Check that Supabase public URL and **publishable/anon** key in `www/config.js` are correct. **Never include a Supabase service-role key.**

### Android APK (Windows, macOS or Linux)

Install Android Studio and the required Android SDK, then:

```sh
npm run android:init
npm run sync
npm run android:open
```

In Android Studio select **Build → Build Bundle(s) / APK(s) → Build APK(s)** for a testing APK, or use **Generate Signed Bundle / APK** for a distributable release. Android Studio reports where the output APK was saved. To publish via Play Store you will usually want a signed Android App Bundle (`.aab`).

### iPhone app (macOS required)

Install Xcode on a Mac, then:

```sh
npm run ios:init
npm run sync
npm run ios:open
```

In Xcode set your Apple Development Team under **Signing & Capabilities** and use Run for testing on your iPhone. To distribute an `.ipa` or App Store app, archive and export/distribute it using Xcode with appropriate Apple signing and distribution permissions.

### Rebuilding when the website changes

```sh
npm run prepare:web
npm run sync
```

Then rebuild in Android Studio or Xcode. **Native copies do not auto-update when you push new HTML to GitHub.**

## Important before migrating data

- Your existing Ride Garage website stores personal garage/trip/service/fuel data locally on the original website's browser origin. The native app uses **separate local storage**. Export a backup from your original web app and import it into the packaged app to migrate data. Test with a backup copy first.
- Social posting and login require a functional `config.js` and Supabase settings; auth redirect rules may need native-app adaptation.
- This starter has not been compiled or tested on Android or iOS hardware in this environment. Test photo selection, backups, Supabase login, social posts, sharing, and external links before distributing.
- Native bundle ID is currently `com.ridegarage.app`; replace with an identifier you control before store release if appropriate.
- iPhone third-party distribution is subject to Apple's signing and distribution rules. Do not assume you can directly install an unsigned `.ipa`.
- iOS App Store review and Google Play review may require additional capabilities/polish beyond simply packaging a website.

## Already installable without builds: PWA

Open the working HTTPS-hosted Ride Garage website using Safari on iPhone and choose **Share → Add to Home Screen** (select Open as Web App when shown). On Android, use Chrome's **Install app / Add to Home screen** menu. This uses the existing manifest and service worker and doesn't require compiling an APK/IPA.
