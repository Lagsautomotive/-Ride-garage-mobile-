#!/usr/bin/env python3
"""Download current Ride Garage static site from its public GitHub repository.
Requires network access. Run locally before initializing or syncing platforms.
"""
import io
import pathlib
import shutil
import urllib.request
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
DEST = ROOT / "www"
URL = "https://github.com/Lagsautomotive/Ride-garage/archive/refs/heads/main.zip"

print("Downloading latest Lagsautomotive/Ride-garage main branch...")
request = urllib.request.Request(URL, headers={"User-Agent": "RideGarageMobileBuilder/1.0"})
with urllib.request.urlopen(request, timeout=50) as response:
    payload = response.read()

with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    web_files = []
    for member in archive.infolist():
        parts = pathlib.PurePosixPath(member.filename).parts
        if len(parts) < 2 or member.is_dir():
            continue
        relative = pathlib.Path(*parts[1:])
        if relative.parts[0].startswith(".") or relative.suffix.lower() not in {
            ".html", ".js", ".css", ".json", ".webmanifest", ".png", ".jpg", ".jpeg", ".webp", ".svg", ".ico", ".woff", ".woff2", ".txt"
        }:
            continue
        web_files.append((member, relative))
    if not any(str(relative) == "index.html" for _, relative in web_files):
        raise SystemExit("No index.html in repository archive; cannot package application.")
    if DEST.exists():
        shutil.rmtree(DEST)
    DEST.mkdir(parents=True)
    for member, relative in web_files:
        out = DEST / relative
        out.parent.mkdir(parents=True, exist_ok=True)
        with archive.open(member) as source, out.open("wb") as target:
            shutil.copyfileobj(source, target)

# Native WebViews use Capacitor's bundled local origin. A service worker originally
# written for hosted GitHub Pages isn't needed inside the native package.
index = DEST / "index.html"
content = index.read_text(encoding="utf-8")
import re
content = re.sub(r"<script>if\('serviceWorker' in navigator\).*?</script>", "", content, flags=re.S)
index.write_text(content, encoding="utf-8")
print(f"Prepared {len(web_files)} site files in {DEST}")
print("Review any runtime config.js values before building. The native app has separate local storage from the website.")
