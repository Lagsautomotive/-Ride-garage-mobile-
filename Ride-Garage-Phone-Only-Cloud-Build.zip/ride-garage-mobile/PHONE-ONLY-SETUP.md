# Ride Garage — no-computer cloud build guide

## First: installable web app (free, immediate)
Open your deployed HTTPS Ride Garage website in Safari (iPhone) > Share > Add to Home Screen > Open as Web App if offered > Add. On Android, open in Chrome > menu > Install app / Add to Home screen. This is the installed website, not an App Store IPA or Android APK.

## GitHub Actions: test Android APK
1. In Safari, open https://github.com/Lagsautomotive/Ride-garage (sign in to an account with write access). In your repo, add the files from this package **to the repository root**, preserving folders: `package.json`, `capacitor.config.json`, `scripts/prepare_web.py`, `www/index.html`, `.github/workflows/android-test-apk.yml`. `codemagic.yaml` is for iOS later. Avoid replacing the existing site's `index.html`: the native wrapper project goes alongside the site's files.
2. GitHub on mobile may not support easy multi-file upload. Safari > Request Desktop Website, then Add file > Upload files, or use GitHub's web editor. Alternatively use a separate repository named `Ride-garage-mobile` containing the whole package. This is simpler and safer: it does not modify the live website. For this **recommended separate repo**, upload all files at repository root and keep its default branch `main`.
3. In the mobile wrapper repository, open **Actions** > **Build Ride Garage Android test APK** > **Run workflow** (may need to enable Actions first).
4. Open completed successful run > **Artifacts** > `Ride-Garage-Android-TEST-APK` to download the ZIP containing `app-debug.apk`. Unzip it on Android and install if you trust the build and allow installs from this source. This is a DEBUG APK for private testing, **not** a signed release package for public distribution/Google Play. It cannot be installed on iPhone.
5. Cloud build uses `scripts/prepare_web.py` to download the latest website from `Lagsautomotive/Ride-garage` at build time. Source site must be accessible. Review `config.js` in downloaded site; use only public Supabase anon/publishable key, NEVER service-role secrets.

## iOS build with Codemagic (cloud Mac)
1. Visit https://codemagic.io/ in Safari and connect the mobile-wrapper GitHub repository.
2. Select `codemagic.yaml`, then run **Ride Garage iOS (unsigned build check)**. This checks compilation, but will **not** produce an iPhone-installable IPA.
3. For TestFlight/App Store: enroll in Apple Developer Program, register a unique bundle ID (replace `com.ridegarage.app` before first release), create the app in App Store Connect, link App Store Connect API key in Codemagic, configure Apple distribution certificate/provisioning with Codemagic, then add a signed archive/export workflow using Codemagic's current Capacitor/iOS documentation. Upload the signed build to TestFlight and test on iPhones before submitting.
4. Alternative installation for iPhone is PWA. There is no broadly available unsigned IPA sideloading route for all iPhones.

## Google Play production
Debug APK is not accepted. Configure Android release signing and make a **signed Android App Bundle (`.aab`)** in cloud CI. Keep your keystore and passwords backed up securely. Match current Play target SDK policy (new app submissions currently require Android 16 / API 36). This starter currently uses Capacitor 7 and is intended for initial build/testing; update native dependencies/target API and validate compatibility before Play submission. Google Play personal accounts opened after Nov 13, 2023 generally require 12 opted-in testers continuously for 14 days before production access.

## App review readiness
- Add in-app account deletion (and a discoverable web deletion option as Google requires) if Social account creation is offered.
- Supply privacy policy, privacy/data safety declarations, community reporting/blocking/moderation, support contact, store screenshots, suitable app icon, and age rating.
- Thoroughly test photo upload, login, password reset redirects, maps/location, backup import/export, and social permissions on BOTH platforms.
- Existing browser garage records are isolated from native WebView storage. Export backup on the website, then restore inside the native app. Preserve existing user data.
- Verify the website's Supabase authentication redirect domain and bundled native origin; Google/Apple sign-in if added later can require native changes.

## Links
- https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow
- https://docs.codemagic.io/yaml-quick-start/building-an-ionic-app/
- https://docs.codemagic.io/yaml-code-signing/signing-ios/
- https://support.google.com/googleplay/android-developer/answer/14151465
